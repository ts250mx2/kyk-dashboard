'use client';

import { useState } from 'react';
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    ResponsiveContainer,
    LineChart,
    Line,
    PieChart,
    Pie,
    Cell,
    AreaChart,
    Area,
} from 'recharts';
import { Table, FileCode, BarChart3, PieChart as PieIcon, LineChart as LineIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ResultsDisplayProps {
    data: any[];
    sql: string;
    visualization: 'table' | 'bar' | 'line' | 'pie' | 'area';
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export function ResultsDisplay({ data, sql, visualization: initialViz }: ResultsDisplayProps) {
    const [view, setView] = useState<'table' | 'chart' | 'sql'>('table');
    const [chartType, setChartType] = useState(initialViz === 'table' ? 'bar' : initialViz);

    if (!data || data.length === 0) return null;

    const keys = Object.keys(data[0]);
    const xKey = keys[0]; // Assume first column is X-axis
    const dataKeys = keys.slice(1); // Rest are data series

    const renderChart = () => {
        const CommonProps = {
            data,
            margin: { top: 5, right: 30, left: 20, bottom: 5 },
        };

        switch (chartType) {
            case 'line':
                return (
                    <LineChart {...CommonProps}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey={xKey} stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <Tooltip
                            contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }}
                        />
                        <Legend />
                        {dataKeys.map((key, index) => (
                            <Line key={key} type="monotone" dataKey={key} stroke={COLORS[index % COLORS.length]} />
                        ))}
                    </LineChart>
                );
            case 'pie':
                return (
                    <PieChart>
                        <Pie
                            data={data}
                            cx="50%"
                            cy="50%"
                            labelLine={false}
                            label={({ name, percent }) => `${name} ${((percent ?? 0) * 100).toFixed(0)}%`}
                            outerRadius={150}
                            fill="#8884d8"
                            dataKey={dataKeys[0]} // Pie only supports one data key usually
                            nameKey={xKey}
                        >
                            {data.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                    </PieChart>
                );
            case 'area':
                return (
                    <AreaChart {...CommonProps}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey={xKey} stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <Tooltip
                            contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }}
                        />
                        <Legend />
                        {dataKeys.map((key, index) => (
                            <Area key={key} type="monotone" dataKey={key} stackId="1" stroke={COLORS[index % COLORS.length]} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </AreaChart>
                );
            case 'bar':
            default:
                return (
                    <BarChart {...CommonProps}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey={xKey} stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <Tooltip
                            contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', color: 'hsl(var(--foreground))' }}
                        />
                        <Legend />
                        {dataKeys.map((key, index) => (
                            <Bar key={key} dataKey={key} fill={COLORS[index % COLORS.length]} />
                        ))}
                    </BarChart>
                );
        }
    };

    const formatValue = (key: string, value: any) => {
        if (typeof value === 'number') {
            const isCurrency = !/Id|Porcentaje|PorcentajeParticipacion|CodigoBarras|CodigoInterno|Codigo|Cantidad|Numero|Count|Year|Mes|Dia|Anio/i.test(key);
            if (isCurrency) {
                return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'MXN' }).format(value);
            }
        }
        return String(value);
    };

    return (
        <div className="w-full max-w-5xl mx-auto mt-8 bg-card border border-border rounded-xl shadow-xl overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b border-border bg-muted/30">
                <div className="flex space-x-2">
                    <button
                        onClick={() => setView('table')}
                        className={cn("p-2 rounded-md hover:bg-accent transition-colors", view === 'table' && "bg-accent text-accent-foreground")}
                        title="Table View"
                    >
                        <Table className="w-5 h-5" />
                    </button>
                    <button
                        onClick={() => setView('chart')}
                        className={cn("p-2 rounded-md hover:bg-accent transition-colors", view === 'chart' && "bg-accent text-accent-foreground")}
                        title="Chart View"
                    >
                        <BarChart3 className="w-5 h-5" />
                    </button>
                    <button
                        onClick={() => setView('sql')}
                        className={cn("p-2 rounded-md hover:bg-accent transition-colors", view === 'sql' && "bg-accent text-accent-foreground")}
                        title="SQL View"
                    >
                        <FileCode className="w-5 h-5" />
                    </button>
                </div>

                {view === 'chart' && (
                    <div className="flex space-x-2">
                        <button onClick={() => setChartType('bar')} className={cn("text-xs px-2 py-1 rounded border", chartType === 'bar' ? "bg-primary text-primary-foreground" : "bg-transparent")}>Bar</button>
                        <button onClick={() => setChartType('line')} className={cn("text-xs px-2 py-1 rounded border", chartType === 'line' ? "bg-primary text-primary-foreground" : "bg-transparent")}>Line</button>
                        <button onClick={() => setChartType('pie')} className={cn("text-xs px-2 py-1 rounded border", chartType === 'pie' ? "bg-primary text-primary-foreground" : "bg-transparent")}>Pie</button>
                        <button onClick={() => setChartType('area')} className={cn("text-xs px-2 py-1 rounded border", chartType === 'area' ? "bg-primary text-primary-foreground" : "bg-transparent")}>Area</button>
                    </div>
                )}
            </div>

            <div className="p-6 overflow-auto max-h-[600px]">
                {view === 'table' && (
                    <table className="w-full text-left text-sm">
                        <thead className="bg-muted/50 text-muted-foreground font-medium">
                            <tr>
                                {keys.map((key) => (
                                    <th key={key} className="px-4 py-3">{key}</th>
                                ))}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-border">
                            {data.map((row, i) => (
                                <tr key={i} className="hover:bg-muted/30 transition-colors">
                                    {keys.map((key) => (
                                        <td key={key} className="px-4 py-3">{formatValue(key, row[key])}</td>
                                    ))}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}

                {view === 'chart' && (
                    <div className="h-[400px] w-full">
                        <ResponsiveContainer width="100%" height="100%">
                            {renderChart()}
                        </ResponsiveContainer>
                    </div>
                )}

                {view === 'sql' && (
                    <pre className="bg-muted p-4 rounded-lg overflow-x-auto font-mono text-sm text-muted-foreground">
                        {sql}
                    </pre>
                )}
            </div>
        </div>
    );
}
