"use client";
import { useState, useRef, useEffect } from 'react';
import { ChatInput } from '@/components/chat-input';
import { ResultsDisplay } from '@/components/results-display';
import { cn } from '@/lib/utils';

export default function Home() {
  interface Message {
    role: 'user' | 'assistant';
    content: string;
    sql?: string;
    visualization?: string;
    data?: any[];
    error?: string;
    suggested_questions?: string[];
  }

  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (prompt: string) => {
    // Add user message
    setMessages((prev) => [...prev, { role: 'user', content: prompt }]);
    setLoading(true);

    try {
      const response = await fetch('/api/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt }),
      });
      const data = await response.json();

      if (response.ok) {
        setMessages((prev) => [...prev, {
          role: 'assistant',
          content: 'SQL executed.',
          sql: data.sql,
          visualization: data.visualization,
          data: data.data,
          suggested_questions: data.suggested_questions
        }]);
      } else {
        setMessages((prev) => [...prev, {
          role: 'assistant',
          content: `Error: ${data.error || 'Error al ejecutar la consulta'}`,
          error: data.error
        }]);
      }
    } catch (err) {
      setMessages((prev) => [...prev, {
        role: 'assistant',
        content: `Error: ${(err as Error).message}`,
        error: (err as Error).message
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex flex-col items-center min-h-screen p-4 bg-background">
      <h1 className="text-3xl font-bold mb-6">Agente IA KYK</h1>
      <div className="w-full max-w-5xl flex flex-col flex-grow">
        <div className="flex-grow overflow-y-auto mb-4 space-y-4">
          {messages.map((msg, i) => (
            <div key={i} className={cn('mb-2', msg.role === 'user' ? 'text-right' : 'text-left')}>
              <div className={cn('inline-block p-2 rounded', msg.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted w-full max-w-none')}>
                <p>{msg.content}</p>

                {msg.data && (
                  <div className="mt-4">
                    <ResultsDisplay
                      data={msg.data}
                      sql={msg.sql || ''}
                      visualization={msg.visualization as any || 'table'}
                    />
                  </div>
                )}

                {msg.suggested_questions && msg.suggested_questions.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <p className="text-sm font-semibold text-muted-foreground">Preguntas sugeridas:</p>
                    <div className="flex flex-wrap gap-2">
                      {msg.suggested_questions.map((question, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleSend(question)}
                          className="px-3 py-1 text-sm bg-background border border-border rounded-full hover:bg-accent transition-colors text-left"
                        >
                          {question}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {loading && <p className="text-muted-foreground">Generando resultados...</p>}
          <div ref={messagesEndRef} />
        </div>

        <div className="sticky bottom-0 bg-background pt-2 w-full max-w-3xl mx-auto">
          <ChatInput onSend={handleSend} isLoading={loading} />
        </div>
      </div>
    </main>
  );
}
