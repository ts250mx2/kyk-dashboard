import { NextResponse } from 'next/server';
import { openai } from '@/lib/ai';
import { query } from '@/lib/db';
import fs from 'fs';
import path from 'path';

export async function POST(req: Request) {
    try {
        const { prompt } = await req.json();

        if (!prompt) {
            return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
        }

        // 1. Get Database Schema from file
        const schemaPath = path.join(process.cwd(), 'database-schema.md');
        const schemaString = fs.readFileSync(schemaPath, 'utf-8');

        // 2. Build system prompt for OpenAI
        const systemPrompt = `
      You are an expert SQL Server (T-SQL) Data Analyst.
      Your task is to convert the user's natural language question into a valid SQL Server query.

      Database Schema:
      ${schemaString}

      Rules:
      1. Return ONLY the SQL query. No markdown, no explanations.
      2. Use only SELECT statements. No INSERT, UPDATE, DELETE, DROP.
      3. If the user asks for visualization, select data appropriate for it.
      4. Use T-SQL syntax (e.g., TOP instead of LIMIT, GETDATE() instead of NOW()).
      5. Limit results to 100 using TOP 100 unless specified otherwise.
      6. Format the output as a JSON object with three keys: 
         - "sql" (string)
         - "visualization" (string: "table", "bar", "line", "pie", "area")
         - "suggested_questions" (array of 3 strings): Suggest 3 follow-up questions based on the query results or related analysis.

      Example Output:
      {
        "sql": "SELECT TOP 10 * FROM users",
        "visualization": "table",
        "suggested_questions": ["Show active users", "Show users by country", "Show new users this month"]
      }
    `;

        // 3. Call OpenAI to get SQL and visualization type
        const completion = await openai.chat.completions.create({
            model: 'gpt-4o',
            messages: [
                { role: 'system', content: systemPrompt },
                { role: 'user', content: prompt },
            ],
            response_format: { type: 'json_object' },
        });

        const content = completion.choices[0].message.content;
        if (!content) {
            throw new Error('No response from AI');
        }
        const aiResponse = JSON.parse(content);

        if (!aiResponse || typeof aiResponse.sql !== 'string') {
            throw new Error('Invalid AI response: missing "sql" field');
        }

        const sqlQuery = aiResponse.sql.trim();
        const visualization = aiResponse.visualization?.trim() ?? 'table';
        const suggestedQuestions = aiResponse.suggested_questions ?? [];

        // 4. Execute the generated SQL query
        let results;
        try {
            results = await query(sqlQuery);
        } catch (execErr: any) {
            console.error('SQL Execution Error:', sqlQuery);
            console.error('SQL Execution Error:', execErr);
            throw new Error(`SQL Execution Failed: ${execErr.message + ' Query: ' + sqlQuery}`);
        }

        // 5. Return the data along with the generated SQL and visualization hint
        return NextResponse.json({
            data: results,
            sql: sqlQuery,
            visualization,
            suggested_questions: suggestedQuestions
        });
    } catch (error: any) {
        console.error('API Error:', error);
        return NextResponse.json(
            { error: error.message || 'Internal Server Error' },
            { status: 500 }
        );
    }
}
